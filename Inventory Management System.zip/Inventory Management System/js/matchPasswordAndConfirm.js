document.getElementById("myForm").addEventListener("submit", validateForm);
function validateForm(event) {
    // Get the values of the password and confirm password fields
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirm-password").value;
  
    // Compare the values
    if (password != confirmPassword) {
      // If they don't match, prevent the form from submitting
      event.preventDefault();
  
      // Update the error message to display to the user
      document.getElementById("error-message").innerHTML = "Password and confirm password do not match!";
    } else {
      // If they match, clear the error message
      document.getElementById("error-message").innerHTML = "";
    }
  }
  