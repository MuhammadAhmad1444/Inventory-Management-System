// Get the query string part of the URL
var queryString = window.location.search;

// Create a new URLSearchParams object
var searchParams = new URLSearchParams(queryString);

// Get the values of the individual parameters
var assignedID = searchParams.get('ASSIGNED_ID');
var data = searchParams.get('data');
var societyName = searchParams.get('SOCIETY_NAME');
var itemName = searchParams.get('ITEM_NAME');
var assignedQuantity = searchParams.get('ASSIGNED_QUANTITY');

var data = JSON.parse(data);

var arr1 = data.arr1;
var arr2 = data.arr2;

// console.log(data.arr1);
// console.log(data.arr2);

var selectSocieties = document.getElementById("menu-2");
for (var i = 0; i < arr1.length; i++) {
  var option = document.createElement("option");
  option.value = arr1[i].ITEM_NAME;
  option.text = arr1[i].ITEM_NAME;
  selectSocieties.appendChild(option);
}

// Select element for societies
var selectItems = document.getElementById("menu-1");
for (var i = 0; i < arr2.length; i++) {
    var option = document.createElement("option");
    option.value = arr2[i].SOCIETY_NAME;
    option.text = arr2[i].SOCIETY_NAME;
    selectItems.appendChild(option);
}

document.getElementById("itemquantity").value=assignedQuantity;

// Get the select element for ItemName to mark as Selected
 var select = document.getElementById("menu-2");

// Loop through each option element 
for (var i = 0; i < select.options.length; i++) {
        // If the value of the option matches the data category
        if (select.options[i].value === itemName) {
                // Set the option as selected
                select.options[i].selected = true;
            break;
        }
    }


// Get the select element for SocietyName to mark as Selected
var select = document.getElementById("menu-1");

// Loop through each option element
for (var i = 0; i < select.options.length; i++) {
        // If the value of the option matches the data category
        if (select.options[i].value === societyName) {
                // Set the option as selected
                select.options[i].selected = true;
            break;
        }
    }
document.querySelector('#form input[name="id"]').value = assignedID;
