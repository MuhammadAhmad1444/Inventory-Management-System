// Get the encoded data from the query string
var encodedData = window.location.search.split('=')[1];

// Decode the data and parse it as a JSON object
var decodedData = decodeURIComponent(encodedData);
var data = JSON.parse(decodedData.replace(/\+/g, " "));

// Access the arrays
var arr1 = data.arr1;
var arr2 = data.arr2;


// Use the arrays as needed
// console.log(arr1);
// console.log(arr2);

// Select element for items
var selectSocieties = document.getElementById("menu-2");
for (var i = 0; i < arr1.length; i++) {
  var option = document.createElement("option");
  option.value = arr1[i].ITEM_NAME;
  option.text = arr1[i].ITEM_NAME;
  selectSocieties.appendChild(option);
}

// Select element for societies
var selectItems = document.getElementById("menu-1");
for (var i = 0; i < arr2.length; i++) {
  var option = document.createElement("option");
  option.value = arr2[i].SOCIETY_NAME;
  option.text = arr2[i].SOCIETY_NAME;
  selectItems.appendChild(option);
}