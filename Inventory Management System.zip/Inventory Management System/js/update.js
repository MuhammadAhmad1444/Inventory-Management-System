// Get the URL parameter containing the data
const urlParams = new URLSearchParams(window.location.search);
const dataParam = urlParams.get('updatedata');

// Parse the JSON-encoded data
const data = JSON.parse(decodeURIComponent(dataParam));

// Set the value of an input field using the data
document.getElementById('itemname').value = data.ITEM_NAME;
document.getElementById('itemdescription').value = data.ITEM_DESCRIPTION;
document.getElementById('itemquantity').value = data.ITEM_QUANTITY;
// Get the select element
var select = document.getElementById("menu");

// Loop through each option element
for (var i = 0; i < select.options.length; i++) {
    // If the value of the option matches the data category
    if (select.options[i].value === data.ITEM_CATEGORY) {
        // Set the option as selected
        select.options[i].selected = true;
        break;
    }
}

// set the id value to the hidden input field
document.querySelector('#form input[name="id"]').value = data.ITEM_ID;