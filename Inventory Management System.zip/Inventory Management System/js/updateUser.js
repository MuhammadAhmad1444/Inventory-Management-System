// Get the URL parameter containing the data
const urlParams = new URLSearchParams(window.location.search);
const dataParam = urlParams.get('updatedata');

// Parse the JSON-encoded data
const data = JSON.parse(decodeURIComponent(dataParam));

// Set the value of an input field using the data
document.getElementById('username').value = data.USERNAME;
document.getElementById('password').value = data.PASSWORD;
document.getElementById('confirm-password').value = data.PASSWORD;


// set the id value to the hidden input field
document.querySelector('#myForm input[name="id"]').value = data.USER_ID;