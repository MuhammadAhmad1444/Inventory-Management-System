//SOCIETIES_ASSINED_ITEMS CHART
//Extract society IDs dynamically from chartData
const societyIDs = Array.from(
  new Set(assignedItemsData.map((data) => data.SOCIETY_ID))
);
const itemIDs = Array.from(new Set(assignedItemsData.map((data) => data.ITEM_ID)));

// Generate labels array dynamically
const labels = societyIDs.map((id) => `Society ${id}`);

// Generate data array for each item
const datasets = itemIDs.map((itemID) => {
  const itemData = societyIDs.map((societyID) => {
    const data = assignedItemsData.find(
      (d) => d.SOCIETY_ID === societyID && d.ITEM_ID === itemID
    );
    return data ? data.ASSIGNED_QUANTITY : 0;
  });

  return {
    label: `Item ${itemID}`,
    data: itemData,
    backgroundColor: `rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(
      Math.random() * 255
    )}, ${Math.floor(Math.random() * 255)}, 0.5)`,
  };
});

// Create the stacked bar chart
const ctx = document
  .getElementById("Societies-Assigned-Items")
  .getContext("2d");
const myChart = new Chart(ctx, {
  type: "bar",
  data: {
    labels: labels,
    datasets: datasets,
  },
  options: {
    maintainAspectRatio: false,
    scales: {
      x: {
        stacked: true,
        grid: {
          display: false,
        },
      },
      y: {
        stacked: true,
      },
    },
    barThickness: 20,
  },
});
//INVENTORY ITEMS CHART
var labels2 = [];
var data2 = [];

inventoryItemsData.forEach(function (item) {
  labels2.push(item.ITEM_CATEGORY);
  data2.push(item.ITEM_QUANTITY);
});

var ctx2 = document.getElementById("Inventory-Items").getContext("2d");
var myChart2 = new Chart(ctx2, {
  type: "bar",
  data: {
    labels: labels2,
    datasets: [
      {
        label: "Inventory Items",
        data: data2,
        backgroundColor: ["#36A2EB", "#FF6384"],
      },
    ],
  },
  options: {
    maintainAspectRatio: false,
    scales: {
      x: {
        grid: {
          display: false,
        },
      },
    },
    barThickness: 20,
  },
});

//CONFIRMED ITEMS CHART
var confirmedCount = 0;
var unconfirmedCount = 0;
confirmedItemsData.forEach(function (item) {
  if (item.CONFIRMED_STATUS == "1") {
    confirmedCount += parseInt(item.ITEM_QUANTITY);
  } else {
    unconfirmedCount += parseInt(item.ITEM_QUANTITY);
  }
});

var ctx3 = document.getElementById("Items-Confirmed-Status").getContext("2d");
var myChart2 = new Chart(ctx3, {
  type: "doughnut",
  data: {
    labels: ["Confirmed", "Unconfirmed"],
    datasets: [
      {
        label: "Confirmed Items",
        data: [confirmedCount, unconfirmedCount],
        backgroundColor: ["#36A2EB", "#FF6384"],
        borderWidth: 1,
      },
    ],
  },
  options: {
    maintainAspectRatio: false,
    cutout: 100,
    radius: 100,
  },
});
