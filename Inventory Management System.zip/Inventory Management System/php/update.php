<?php
    require_once('dbConnection.php');
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $id=$_POST['id'];
        $itemName = $_POST['itemname'];
        $itemDescription = $_POST['itemdescription'];
        $itemQuantity = $_POST['itemquantity'];
        $category = $_POST['category'];
        $itemAddedBy = "Anonymous";
        $query="UPDATE F219457.INVENTORY_ITEMS 
                SET ITEM_NAME='$itemName',ITEM_DESCRIPTION='$itemDescription',ITEM_QUANTITY=$itemQuantity,ITEM_CATEGORY='$category',ITEM_ADDEDBY='$itemAddedBy' 
                WHERE ITEM_ID=$id";
        $result=odbc_exec($conn,$query);

        if($result==true){
            header('Location:inventory.php');
        }
        else{
            die("Connection failed: " . odbc_errormsg());
        }
    }

?>