<?php
    require_once('dbConnection.php');
    $assignedID=$_GET['assigned_id'];
    $query="SELECT CONFIRMED_STATUS	FROM F219457.SOCIETIES_ASSIGNED_ITEMS WHERE ASSIGNED_ID=$assignedID";
    $result=odbc_exec($conn,$query);
    $row=odbc_fetch_array($result);
    $status=$row['CONFIRMED_STATUS'];
    if($status) {
        $Query="SELECT ITEM_ID,ASSIGNED_QUANTITY FROM F219457.SOCIETIES_ASSIGNED_ITEMS WHERE ASSIGNED_ID=$assignedID";
        $res=odbc_exec($conn,$Query);
        $data=odbc_fetch_array($res);
        $itemID=$data['ITEM_ID'];
        $assignedQuantity=$data['ASSIGNED_QUANTITY'];
        
        //Check that a Items exists or not in the inventory
        $Query="SELECT * FROM F219457.INVENTORY_ITEMS WHERE ITEM_ID= $itemID";
        $res=odbc_exec($conn,$Query);
        if (odbc_num_rows($res) == 0) {
            $Q="SELECT ITEM_NAME FROM F219457.DELETED_ITEM_NAMES WHERE ID=$itemID";
            $RS=odbc_exec($conn,$Q);
            $RW=odbc_fetch_array($RS);
            $itemName=$RW['ITEM_NAME'];

            $Q="INSERT INTO F219457.INVENTORY_ITEMS (ITEM_NAME,ITEM_QUANTITY,ITEM_CATEGORY,ITEM_ADDEDBY) VAlUES ('$itemName',$assignedQuantity,' ','Anonymous')";
            odbc_exec($conn,$Q);

            $Q="DELETE FROM F219457.DELETED_ITEM_NAMES WHERE ID=$itemID";
            odbc_exec($conn,$Q);

        } else {
            $Q="UPDATE F219457.INVENTORY_ITEMS SET ITEM_QUANTITY = ITEM_QUANTITY + $assignedQuantity WHERE ITEM_ID = $itemID";
            odbc_exec($conn,$Q);
        }
        
    }
    
    $query="DELETE FROM F219457.SOCIETIES_ASSIGNED_ITEMS WHERE ASSIGNED_ID=$assignedID";
    odbc_exec($conn,$query);

    if($status)
    header('Location:inventory.php');
    else
    header('Location:societiesItems.php');
?>