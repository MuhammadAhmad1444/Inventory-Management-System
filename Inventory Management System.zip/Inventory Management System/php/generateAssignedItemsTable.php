<?php

$itemAssignedBy = $_SESSION['LOGGED_IN_USER_NAME'];
global $data;
require_once('dbConnection.php');
$query="SELECT sai.assigned_id,s.society_name, ii.item_name,sai.assigned_quantity,sai.confirmed_status,sai.ASSIGNED_BY
FROM F219457.SOCIETIES_ASSIGNED_ITEMS sai
INNER JOIN F219457.SOCIETIES s ON sai.society_id = s.society_id
INNER JOIN F219457.INVENTORY_ITEMS ii ON sai.item_id = ii.item_id WHERE sai.ASSIGNED_BY = '$itemAssignedBy'";
$result=odbc_exec($conn,$query);

echo '<table>';
//Display the table header
echo '<thead>
      <tr>
      <th>Assigned Id</th>
      <th>Society Name</th>
      <th>Item Name</th>
      <th>Assigned Quantity</th>
      <th>Confirmed Status</th>
      <th>Assigned By</th>
      <th>Operations</th>
      </tr>
      </thead>';

//Display the table body
echo '<tbody>';
while($row=odbc_fetch_array($result)){
    echo '<tr>';
    echo '<td>'.$row['ASSIGNED_ID'].'</td>';
    echo '<td>'.$row['SOCIETY_NAME'].'</td>';
    echo '<td>'.$row['ITEM_NAME'].'</td>';
    echo '<td>'.$row['ASSIGNED_QUANTITY'].'</td>';
    echo '<td>'.$row['CONFIRMED_STATUS'].'</td>';
    echo '<td>'.$row['ASSIGNED_BY'].'</td>';
        echo '<td>
                    <div id="operations">';
                    if ($row['CONFIRMED_STATUS'] != 1) {
                        echo '<a href="confirmStatus.php?assigned_id='.$row['ASSIGNED_ID'].'"><button type="button">Confirm</button></a>';
                        echo '<a href="../updateAssignItems.html?data='.$data.'&SOCIETY_NAME='.$row['SOCIETY_NAME'].'&ITEM_NAME='.$row['ITEM_NAME'].'&ASSIGNED_QUANTITY='.$row['ASSIGNED_QUANTITY'].'&ASSIGNED_ID='.$row['ASSIGNED_ID'].'"><button type="button">Update</button></a>';
                    } else {
                        echo '<button type="button" disabled class="disabled">Confirm</button>';
                        echo '<button type="button" disabled class="disabled">Update</button>';
                    }
                    echo '<a href="returnAssignItems.php?assigned_id='.$row['ASSIGNED_ID'].'"><button type="button">Return</button></a>
                    </div>
              </td>';
    echo '</tr>';
}
echo '<tbody>';
odbc_close($conn);
?>
