<?php

$itemAddedBy = $_SESSION['LOGGED_IN_USER_NAME'];

require_once('dbConnection.php');
$query="SELECT * FROM F219457.INVENTORY_ITEMS WHERE ITEM_ADDEDBY = '$itemAddedBy' ORDER BY ITEM_ID ";
$result=odbc_exec($conn,$query);

echo '<table>';
//Display the table header
echo '<thead>';
echo '<tr>
      <th>Item Id</th>
      <th>Item Name</th>
      <th>Item Description</th>
      <th>Item Quantity</th>
      <th>Item Category</th>
      <th>Item AddedBy</th>';
if((isset($_SESSION['Add_Actions_Col_in_Table']))){
    echo '<th>Operations</th>';
}
echo '</tr>';
echo '</thead>';

//Display the table body
echo '<tbody>';
while($row=odbc_fetch_array($result)){
    echo '<tr>';
    echo '<td>'.$row['ITEM_ID'].'</td>';
    echo '<td>'.$row['ITEM_NAME'].'</td>';
    echo '<td>'.$row['ITEM_DESCRIPTION'].'</td>';
    echo '<td>'.$row['ITEM_QUANTITY'].'</td>';
    echo '<td>'.$row['ITEM_CATEGORY'].'</td>';
    echo '<td>'.$row['ITEM_ADDEDBY'].'</td>';
    if(isset($_SESSION['Add_Actions_Col_in_Table'])){
        echo '<td>
                    <div id="operations">
                    <a href="../update.html?updatedata='.urlencode(json_encode($row)).'"><button type="button">Update</button></a>
                    <a href="delete.php?deleteid='.$row['ITEM_ID'].'"><button type="button">Delete</button></a>
                    </div>
              </td>';
    }
    echo '</tr>';
}
echo '<tbody>';
odbc_close($conn);
unset($_SESSION['Add_Actions_Col_in_Table']);
?>
