<?php
    require_once('dbConnection.php');
    $userID=$_POST['id'];
    $userName=$_POST['username'];
    $password=$_POST['password'];
    
    $query="UPDATE F219457.USER_TABLE SET USERNAME='$userName',PASSWORD='$password' WHERE USER_ID=$userID";
    $result=odbc_exec($conn,$query);
    if($result==true){
        header('Location:userDetails.php');
    }
    else{
        die("Connection failed: " . odbc_errormsg());
    }
?>