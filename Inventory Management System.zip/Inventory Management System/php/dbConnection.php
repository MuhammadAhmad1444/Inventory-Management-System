<?php
 //Connection to database

    //Define connection parameters
    $dsn = 'OracleDataSource';
    $username = 'system';
    $password = 'system';

    // Connect to the Oracle database
    $conn = odbc_connect($dsn, $username, $password);
?>