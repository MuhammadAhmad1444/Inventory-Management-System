<?php 
    require_once('dbConnection.php');
    $id =$_GET['approveid'];
    $query="UPDATE F219457.REQUESTED_ITEMS SET CONFIRMED_STATUS=1 WHERE REQUEST_ID= $id";
    $result = odbc_exec($conn,$query);
    if($result==true){
        header('Location:requestDetails.php');
    }
    else{
        die("Connection failed: " . odbc_errormsg());
    }
?>