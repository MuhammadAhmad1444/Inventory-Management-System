<?
require_once('dbConnection.php');
$query="SELECT COUNT(*) AS TOTAL_ADDED_ITEMS FROM F219457.INVENTORY_ITEMS";
$result=odbc_exec($conn,$query);
$row=odbc_fetch_array($result);
$totalItemsAdded=$row['TOTAL_ADDED_ITEMS'];
//
$query="SELECT COUNT(*) AS TOTAL_ASSIGNED_ITEMS FROM F219457.SOCIETIES_ASSIGNED_ITEMS";
$result=odbc_exec($conn,$query);
$row=odbc_fetch_array($result);
$totalItemsAssigned=$row['TOTAL_ASSIGNED_ITEMS'];
// var_dump($totalItemsAdded);
// echo '<br>';
// var_dump($totalItemsAssigned);
?>