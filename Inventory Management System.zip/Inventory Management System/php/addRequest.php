<?php
    session_start();
    $itemRequestedBy = $_SESSION['LOGGED_IN_USER_NAME'];

    require_once('dbConnection.php');
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $societyName = $_POST['societiesNameOptions'];
        $itemName = $_POST['itemNameOptions'];
        $itemQuantity = $_POST['itemquantity'];
    
      
        $query="SELECT SOCIETY_ID FROM F219457.SOCIETIES WHERE SOCIETY_NAME ='$societyName'";
        $result=odbc_exec($conn,$query);
        $s_id = odbc_fetch_array($result);
        $societyID = $s_id['SOCIETY_ID'];
       
        $query="SELECT ITEM_ID  FROM F219457.INVENTORY_ITEMS WHERE ITEM_NAME='$itemName'";
        $result=odbc_exec($conn,$query);
        $i_id = odbc_fetch_array($result);
        $itemID = $i_id['ITEM_ID'];

        $query="INSERT INTO F219457.REQUESTED_ITEMS (SOCIETY_ID,ITEM_ID,REQUESTED_QUANTITY,REQUESTED_BY) VALUES($societyID,$itemID,$itemQuantity,'$itemRequestedBy')";
        $result=odbc_exec($conn,$query);

        if($result==true){
            header('Location:requestItems.php');
        }
        else{
            die("Connection failed: " . odbc_errormsg());
        }
    }

?>