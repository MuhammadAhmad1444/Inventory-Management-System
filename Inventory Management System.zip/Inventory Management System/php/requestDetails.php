<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Details</title>
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link href="../css/requestDetails.css" rel="stylesheet">
</head>

<body>
    <div id="main-container">
        <div class="side-bar">
        <div class="bar-icon icon-top">
                <a href="s_adminDashboard.php">
                    <i class="material-symbols-outlined icon-hover">home</i></a>
            </div>
            <div class="bar-icon">
                <a href="userDetails.php">
                    <i class="material-symbols-outlined icon-hover">person_add</i></a>
            </div>
            <div class="bar-icon">
                <a href="requestDetails.php">
                    <i class="material-symbols-outlined icon-hover">thumb_up</i></a>
            </div>

            <div class="bar-icon icon-bottom">
                <a href="#">
                    <i class="material-symbols-outlined icon-hover">logout</i>
                </a>
            </div>
        </div>
        <div class="table-top">
                <div class="table-top-right">
                    <form action="#" method="GET" class="search-form">
                        <input type="search" name="searchbar" placeholder="Enter Item id#">
                        <button type="submit">Search</button>
                    </form>
                </div>
        </div>
        <div class="table-bottom">
            <?php require_once 'generateRequestDetailsTable.php'; ?>
        </div>
    </div>
</body>
</html>