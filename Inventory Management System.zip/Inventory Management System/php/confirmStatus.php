<?php 
    require_once('dbConnection.php');
    $assigned_id=$_GET['assigned_id'];


    $query="SELECT ITEM_ID,ASSIGNED_QUANTITY FROM F219457.SOCIETIES_ASSIGNED_ITEMS WHERE ASSIGNED_ID= $assigned_id";
    $result=odbc_exec($conn,$query);
    $row=odbc_fetch_array($result);
    $item_id=$row['ITEM_ID'];
    $assignedQuantity=$row['ASSIGNED_QUANTITY'];
    
    $query="SELECT ITEM_QUANTITY FROM F219457.INVENTORY_ITEMS WHERE ITEM_ID=$item_id";
    $result=odbc_exec($conn,$query);
    $row=odbc_fetch_array($result);
    $item_quantity=$row['ITEM_QUANTITY'];

    $remaining_Quantity=$item_quantity-$assignedQuantity;

    if(!($remaining_Quantity < 0)){
        $query="UPDATE F219457.INVENTORY_ITEMS SET ITEM_QUANTITY = $remaining_Quantity WHERE ITEM_ID=$item_id";
        $result=odbc_exec($conn,$query);
                
        $query="UPDATE F219457.SOCIETIES_ASSIGNED_ITEMS SET CONFIRMED_STATUS=1 WHERE ASSIGNED_ID= $assigned_id";
        $result=odbc_exec($conn,$query);
        if($result){
            header('Location:societiesItems.php');
        }else{
            die("Connection failed: " . odbc_errormsg());
        }
    }else{
        header('Location:societiesItems.php?error="Error:Not Enough Item Quantity"');
    }

?>