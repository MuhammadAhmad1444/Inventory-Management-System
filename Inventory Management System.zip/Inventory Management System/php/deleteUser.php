<?php
    require_once('dbConnection.php');
    if(isset($_GET['deleteid'])){
        $userID=$_GET['deleteid'];
        $query="DELETE FROM F219457.USER_TABLE WHERE USER_ID=$userID";
        $result=odbc_exec($conn,$query);
        if($result==true){
            header('Location:userDetails.php');
        }
        else{
            die("Connection failed: " . odbc_errormsg());
        }
    }
?>