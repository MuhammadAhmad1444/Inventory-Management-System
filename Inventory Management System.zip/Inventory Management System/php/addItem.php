<?php
session_start();


    require_once('dbConnection.php');
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $itemName = $_POST['itemname'];
        $itemDescription = $_POST['itemdescription'];
        $itemQuantity = $_POST['itemquantity'];
        $category = $_POST['category'];
        $itemAddedBy = $_SESSION['LOGGED_IN_USER_NAME'];
        $query="INSERT INTO F219457.INVENTORY_ITEMS (ITEM_NAME,ITEM_DESCRIPTION,ITEM_QUANTITY,ITEM_CATEGORY,ITEM_ADDEDBY) 
        VALUES('$itemName', '$itemDescription', $itemQuantity, '$category', '$itemAddedBy')";
        $result=odbc_exec($conn,$query);

        if($result==true){
            header('Location:inventory.php');
        }
        else{
            die("Connection failed: " . odbc_errormsg());
        }
    }

?>