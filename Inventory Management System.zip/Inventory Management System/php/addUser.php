<?php 
    require_once('dbConnection.php');
    $username=$_POST['username'];
    $password=$_POST['password'];
    $sql="INSERT INTO F219457.USER_TABLE (USERNAME,PASSWORD) VALUES ('$username','$password')";
    $result=odbc_exec($conn,$sql);
    if($result==true){
        header('Location:userDetails.php');
    }
    else{
        die("Connection failed: " . odbc_errormsg());
    }
?>