<?php
require_once('dbConnection.php');

if(isset($_GET['deleteid'])){

    $id=$_GET['deleteid'];
    $query="DELETE FROM F219457.INVENTORY_ITEMS WHERE ITEM_ID=$id";

    try {
        $result = @odbc_exec($conn, $query);
        if($result) {
            header('Location:inventory.php');
            exit();
        } else {
              // Check for foreign key constraint violation
              $sql = "SELECT CONSTRAINT_NAME, TABLE_NAME FROM all_constraints WHERE CONSTRAINT_NAME='ITEM_ID_FK' OR CONSTRAINT_NAME='FK_REQUESTED_ITEMS_ITEM_ID'";
              $res = odbc_exec($conn, $sql);
    
              $error = "Error: Item cannot be deleted. It is referenced by the following table(s):<br>";
              while($row = odbc_fetch_array($res)) {
                  $error .= $row['TABLE_NAME'] . "<br>";
              }
              throw new Exception($error);
        }
    } catch(Exception $e) {
        $error = $e->getMessage();
        header("Location: inventory.php?error=$error");
        exit();
    }
}
?>

