<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Get the username and password from the form
    $name = $_POST['username'];
    $pass = $_POST['pass'];

    //Creating Session Variable for Userthat logs in
    $_SESSION['LOGGED_IN_USER_NAME'] = $name;



    //Connection to database

    //Define connection parameters
    $dsn = 'OracleDataSource';
    $username = 'system';
    $password = 'system';

    // Connect to the Oracle database
    $conn = odbc_connect($dsn, $username, $password);

    if (!$conn) {
        exit('Connection failed' . '<br>');
    }
    $query = "SELECT IS_ADMIN FROM F219457.USER_TABLE WHERE USERNAME='$name' AND PASSWORD ='$pass'";
    $result = odbc_exec($conn, $query);


    $row = odbc_fetch_array($result);
    
    if ($row && $row['IS_ADMIN'] == 1) {
        $_SESSION['loggedin'] = true;
        header('Location: s_adminDashboard.php');

    } else if ($row && $row['IS_ADMIN'] == 0) {
        $_SESSION['loggedin'] = true;
       header('Location: temp_adminDashboard.php');

    } else {
        $_SESSION['loggedin'] = false;
        header('Location: ../login.html');
    }
    odbc_close($conn);
}
?>