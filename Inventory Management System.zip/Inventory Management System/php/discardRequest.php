<?php 
    require_once('dbConnection.php');
    $id =$_GET['discardid'];
    $query="DELETE FROM F219457.REQUESTED_ITEMS WHERE REQUEST_ID= $id";
    $result = odbc_exec($conn,$query);
    if($result==true){
        header('Location:requestDetails.php');
    }
    else{
        die("Connection failed: " . odbc_errormsg());
    }
?>