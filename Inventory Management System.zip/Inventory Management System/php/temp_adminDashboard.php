<?php 
 session_start();
 
//  if(!isset($_SESSION['loggedin']) || !$_SESSION['loggedin']){
//      header("Location: ../login.html");
//      exit();
//  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600&display=swap" rel="stylesheet" />
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link href="../css/tempAdmin.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>

    <div class="main-container">
        <div class="side-bar">
            <div class="bar-icon icon-top"><a href="temp_adminDashboard.php"><i class="material-symbols-outlined icon-hover">home</i></a></div>
            <div class="bar-icon"><a href="inventory.php"><i class="material-symbols-outlined icon-hover">inventory_2</i></a></div>
            <div class="bar-icon"><a href="societiesItems.php"><i class="material-symbols-outlined icon-hover">assignment_turned_in</i></a></div>
            <div class="bar-icon"><a href="requestItems.php"><i class="material-symbols-outlined icon-hover">request_quote</i></a></div>
            <div class="bar-icon icon-bottom"><a href="#"><i class="material-symbols-outlined icon-hover">logout</i></a></div>
        </div>
        <div class="top">
            <?php 
            require_once('generateHeaderData.php');
            echo '<div class="header-card-1">';
            echo '<div class="header-card-1-inner">';
            echo "$totalItemsAdded";
            echo '<i class="material-symbols-outlined">add_box</i>';
            echo '</div>';
            echo'</br>';
            echo '<span>Total Added Items</span>';
            echo '</div>';
            echo '<div class="header-card-2">';
            echo '<div class="header-card-2-inner">';
            echo "$totalItemsAssigned";
            echo '<i class="material-symbols-outlined">assignment_turned_in</i>';
            echo '</div>';
            echo'</br>';
            echo '<span>Total Assigned Items</span>';
            echo '</div>';
            echo '<div class="header-card-3">';
            echo '<div class="header-card-3-inner">';
            echo "$totalItemsAssigned";
            echo '<i class="material-symbols-outlined">assignment_turned_in</i>';
            echo '</div>';
            echo'</br>';
            echo '<span>Total Assigned Items</span>';
            echo '</div>';
            ?>
        </div>
        <div class="middle">
            <div class="chart1">
                <canvas id="Societies-Assigned-Items"></canvas>
            </div>
            <div class="chart2">
                <canvas id="Inventory-Items"></canvas>
            </div>
            <div class="chart3">
                <canvas id="Items-Confirmed-Status"></canvas>
            </div>
            <?php require_once 'generateCharts.php'; ?>
        </div>
        <div class="bottom-head">
            <span id="table-title">Inventory Items</span>
            <div class="table-top-right">
                <label for="menu">Category</label>
                <select id="menu">
                    <option value="">All</option>
                    <option value="">Stationary</option>
                    <option value="">Electronics</option>
                </select>
                <form action="#" method="GET" class="search-form">
                    <input type="search" name="searchbar" placeholder="Enter Item id#">
                    <button type="submit">Search</button>
                </form>
            </div>
        </div>
        <div class="bottom">
            <?php require_once 'generateTable.php'; ?>
        </div>
    </div>
    <script src="../js/chart.js"></script>
</body>

</html>