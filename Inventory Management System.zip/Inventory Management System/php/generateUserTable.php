<?php
require_once('dbConnection.php');
$query="SELECT * FROM F219457.USER_TABLE ORDER BY USER_ID";
$result=odbc_exec($conn,$query);

echo '<table>';
//Display the table header
echo '<thead>';
echo '<tr>
      <th>User Id</th>
      <th>User Name</th>
      <th>Password</th>
      <th>Is Admin</th>
      <th>Operations</th>';
echo '</tr>';
echo '</thead>';

//Display the table body
echo '<tbody>';
while($row=odbc_fetch_array($result)){
    echo '<tr>';
    echo '<td>'.$row['USER_ID'].'</td>';
    echo '<td>'.$row['USERNAME'].'</td>';
    echo '<td>'.$row['PASSWORD'].'</td>';
    echo '<td>'.$row['IS_ADMIN'].'</td>';
    echo '<td>
                    <div id="operations">
                    <a href="../updateUser.html?updatedata='.urlencode(json_encode($row)).'"><button type="button">Update</button></a>';
                    if($row['IS_ADMIN']==1){
                        echo '<a href="#"><button type="button" disabled>Delete</button></a>';
                    }
                    else{
                        echo '<a href="deleteUser.php?deleteid='.$row['USER_ID'].'"><button type="button">Delete</button></a>';
                    }
                    echo '</div>
          </td>';
    echo '</tr>';
}
echo '<tbody>';
odbc_close($conn);

?>
