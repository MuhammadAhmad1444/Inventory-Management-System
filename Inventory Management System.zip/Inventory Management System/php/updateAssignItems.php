<?php
    require_once('dbConnection.php');
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $societyName = $_POST['societiesNameOptions'];
        $itemName = $_POST['itemNameOptions'];
        $itemQuantity = $_POST['itemquantity'];
        $assignedID = $_POST['id'];
      
        $query="SELECT SOCIETY_ID FROM F219457.SOCIETIES WHERE SOCIETY_NAME ='$societyName'";
        $result=odbc_exec($conn,$query);
        $s_id = odbc_fetch_array($result);
        $societyID = $s_id['SOCIETY_ID'];
       
        $query="SELECT ITEM_ID  FROM F219457.INVENTORY_ITEMS WHERE ITEM_NAME='$itemName'";
        $result=odbc_exec($conn,$query);
        $i_id = odbc_fetch_array($result);
        $itemID = $i_id['ITEM_ID'];

        $query="SELECT * FROM F219457.REQUESTED_ITEMS WHERE ITEM_ID	=$itemID AND SOCIETY_ID=$societyID AND REQUESTED_QUANTITY >= $itemQuantity";
        $result=odbc_exec($conn,$query);
        
        if($row=(odbc_fetch_array($result))){
            $request_id=$row['REQUEST_ID'];

            //First add assigned quantity back to request quantity
            $Query="SELECT ASSIGNED_QUANTITY FROM F219457.SOCIETIES_ASSIGNED_ITEMS WHERE ASSIGNED_ID= $assignedID";
            $Result=odbc_exec($conn,$Query);
            $row=(odbc_fetch_array($Result));
            $assignedQuantity=$row['ASSIGNED_QUANTITY'];

            $Query="UPDATE F219457.REQUESTED_ITEMS SET REQUESTED_QUANTITY = (REQUESTED_QUANTITY + $assignedQuantity) WHERE REQUEST_ID=$request_id";
            odbc_exec($conn,$Query);

            //Now subtract the item quantity from requested quantity
            $Query="UPDATE F219457.REQUESTED_ITEMS SET REQUESTED_QUANTITY = (REQUESTED_QUANTITY - $itemQuantity) WHERE REQUEST_ID=$request_id";
            odbc_exec($conn,$Query);
            
            $Query="SELECT REQUESTED_QUANTITY FROM F219457.REQUESTED_ITEMS WHERE REQUEST_ID=$request_id";
            $Result=odbc_exec($conn,$Query);
            $row=(odbc_fetch_array($Result));

            if($row['REQUESTED_QUANTITY']==0){
                $Q="DELETE FROM F219457.REQUESTED_ITEMS WHERE REQUEST_ID=$request_id";
                odbc_exec($conn,$Q);
            }

            $Query = "UPDATE F219457.SOCIETIES_ASSIGNED_ITEMS SET SOCIETY_ID=$societyID, ITEM_ID=$itemID, ASSIGNED_QUANTITY=$itemQuantity WHERE ASSIGNED_ID=$assignedID";
            $Result = odbc_exec($conn, $Query);
            
            if($Result==true){ 
                header('Location:societiesItems.php');
            }
            else{
                die("Connection failed: " . odbc_errormsg());
            }
        }else{
            header('Location:../updateAssignItems.html?error="Error:Item not Approved.You have to approve the request first."');
        }

    }

?>