<?php
    session_start();
    require_once('dbConnection.php');
    $query="SELECT ITEM_NAME FROM F219457.INVENTORY_ITEMS";
    $result=odbc_exec($conn,$query);
    
    $arr1 = array();
    while ($row = odbc_fetch_array($result)) {
        $arr1[] = $row;
    }

    
    $query="SELECT SOCIETY_NAME FROM F219457.SOCIETIES ";
    $result=odbc_exec($conn,$query);
    $arr2 = array();
    while ($row = odbc_fetch_array($result)) {
        $arr2[] = $row;
    }

    // Encode the arrays as a string
    $data = urlencode(json_encode(array('arr1' => $arr1, 'arr2' => $arr2)));
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Societies Assigned Items</title>
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link href="../css/inventory.css" rel="stylesheet">
</head>

<body>
    <div id="main-container">
        <div class="side-bar">
            <div class="bar-icon icon-top">
                <a href="temp_adminDashboard.php">
                    <i class="material-symbols-outlined icon-hover">home</i></a>
            </div>
            <div class="bar-icon">
                <a href="inventory.php">
                    <i class="material-symbols-outlined icon-hover">inventory_2</i></a>
            </div>
            <div class="bar-icon">
                <a href="societiesItems.php">
                    <i class="material-symbols-outlined icon-hover">assignment_turned_in</i>
                </a>
            </div>
            <div class="bar-icon">
                <a href="requestItems.php">
                    <i class="material-symbols-outlined icon-hover">request_quote</i>
                </a>
            </div>
            <div class="bar-icon icon-bottom">
                <a href="#">
                    <i class="material-symbols-outlined icon-hover">logout</i>
                </a>
            </div>
        </div>
        <div class="table-top">
                <a href="../assignItems.html?data=<?php echo $data; ?>"><button type="button">Assign Items</button></a>
                <div class="table-top-right">
                    <label for="menu">Category</label>
                    <select id="menu">
                        <option value="red">All</option>
                        <option value="green">Stationary</option>
                        <option value="blue">Electronics</option>
                    </select>
                    <form action="#" method="GET" class="search-form">
                        <input type="search" name="searchbar" placeholder="Enter Item id#">
                        <button type="submit">Search</button>
                    </form>
                </div>
        </div>
        <div class="table-bottom">
            <?php require_once 'generateAssignedItemsTable.php'; ?>
        </div>
    </div>
</body>

</html>