<?php
require_once('dbConnection.php');
$query = "SELECT ri.REQUEST_ID,s.society_name, ii.item_name,ri.REQUESTED_QUANTITY,ri.CONFIRMED_STATUS
FROM F219457.REQUESTED_ITEMS ri
INNER JOIN F219457.SOCIETIES s ON ri.society_id = s.society_id
INNER JOIN F219457.INVENTORY_ITEMS ii ON ri.item_id = ii.item_id
ORDER BY REQUEST_ID";

$result = odbc_exec($conn, $query);

echo '<table>';
//Display the table header
echo '<thead>
      <tr>
      <th>Request Id</th>
      <th>Society Name</th>
      <th>Item Name</th>
      <th>Requested Quantity</th>
      <th>Confirmed Status</th>
      <th>Operations</th>
      </tr>
      </thead>';

//Display the table body
echo '<tbody>';
while ($row = odbc_fetch_array($result)) {
    echo '<tr>';
    echo '<td>' . $row['REQUEST_ID'] . '</td>';
    echo '<td>' . $row['SOCIETY_NAME'] . '</td>';
    echo '<td>' . $row['ITEM_NAME'] . '</td>';
    echo '<td>' . $row['REQUESTED_QUANTITY'] . '</td>';
    echo '<td>' . $row['CONFIRMED_STATUS'] . '</td>';
    echo '<td>
                <div id="operations">
                    <a href="approveRequest.php?approveid=' . $row['REQUEST_ID'] .'"><button type="button">Approve</button></a>
                    <a href="discardRequest.php?discardid=' . $row['REQUEST_ID'] . '"><button type="button">Discard</button></a>
                    
                </div>
          </td>';
    echo '</tr>';

}
echo '<tbody>';
odbc_close($conn);
?>