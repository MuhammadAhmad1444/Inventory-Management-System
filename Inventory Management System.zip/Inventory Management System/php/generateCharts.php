<?php
$ByUser = $_SESSION['LOGGED_IN_USER_NAME'];


//FOR SOCIETIES_ASSINED_ITEMS CHART
require_once('dbConnection.php');
$query="SELECT SOCIETY_ID,ITEM_ID,SUM(ASSIGNED_QUANTITY) AS ASSIGNED_QUANTITY FROM F219457.SOCIETIES_ASSIGNED_ITEMS WHERE ASSIGNED_BY= '$ByUser' GROUP BY SOCIETY_ID,ITEM_ID";
$result=odbc_exec($conn, $query);
$data=array();
while($row = odbc_fetch_array($result)){
    $data[]=$row;
}
$data_json=json_encode($data);
echo '<script>var assignedItemsData ='.$data_json.';</script>';

//FOR INVENTORY ITEMS CHART
$query="SELECT ITEM_CATEGORY,SUM(ITEM_QUANTITY) AS ITEM_QUANTITY FROM F219457.INVENTORY_ITEMS WHERE ITEM_ADDEDBY= '$ByUser' GROUP BY ITEM_CATEGORY";
$result=odbc_exec($conn, $query);
$data=array();
while($row = odbc_fetch_array($result)){
    $data[]=$row;
}
$data_json=json_encode($data);
echo '<script>var inventoryItemsData ='.$data_json.';</script>';

//FOR ITEMS CONFIRMED STATUS CHART
$query="SELECT CONFIRMED_STATUS,COUNT(*) AS ITEM_QUANTITY FROM F219457.SOCIETIES_ASSIGNED_ITEMS WHERE ASSIGNED_BY='$ByUser' GROUP BY CONFIRMED_STATUS";
$result=odbc_exec($conn, $query);
$data=array();
while($row = odbc_fetch_array($result)){
    $data[]=$row;
}
$data_json=json_encode($data);
echo '<script>var confirmedItemsData ='.$data_json.';</script>';
?>